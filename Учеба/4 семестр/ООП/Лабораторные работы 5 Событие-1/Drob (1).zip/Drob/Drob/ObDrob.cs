﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace Drob
{

    class ObDrob
    {
        public delegate void ChangeHandler(ObDrob sender, EventArgs e);
        public delegate void ZeroHandler(ObDrob sender, DrobArgs e);
        public delegate bool ChangingHandler(ObDrob sender, DrobArgs e);
        string _name;
        bool simple;
        bool changable; 
        int _p, _q;
        public event ChangeHandler OnChange;
        public event ZeroHandler OnZero;
        public event ChangingHandler OnChanging;

        public bool Changable
        {
            get { return changable; }
            set { changable = value; }
        }
        public bool Simple
        {
            get { return simple; }
            private set
            {
                if (changable)
                {
                    if (value)
                    {
                        if (P > Q) Swap();
                    }
                    else
                        if (Q > P) Swap();
                    simple = value;
                }
            }
        }
        public string Name
        {
            get
            {
                return _name;
            }
        }
        public int P
        {
            get { return _p; }
            set
            {
                SetDrob(value, Q);
            }
        }
        public int Q
        {
            get { return _q; }
            set
            {
                SetDrob(P,value);
            }
        }
        public double Value
        {
            get
            {
                return (double)P / Q;
            }
            set
            {
                if (Math.Abs(value) > 1e9) return;
                int qq = 1;
                while (Math.Truncate(value)!=value)
                {
                    value *= 10;
                    qq *= 10;
                    if (qq > 1e8) break;
                }
                SetDrob((int)value, qq);
            }
        }
        public void Normalization(ref int nP, ref int nQ)
        {
            if ((nP<0)&(nQ<0))
            {
                nP *= -1;nQ *= -1;
            }
            if ((nP > 0) & (nQ < 0))
            {
                nP *= -1; nQ *= -1;
            }
            int obshnaibmn = 1;
            if (nP != 0)
            {
                foreach (var item in GetObshMn(nP, nQ))
                {
                    obshnaibmn *= item;
                }
                nP /= obshnaibmn;
                nQ /= obshnaibmn;
            }

        }
        public List<int> GetProstDelit(int n)
        {
            List<int> lis = new List<int>();
            int b, c;
            while ((n % 2) == 0)
            {
                n = n / 2;
                lis.Add(2);
            }
            b = 3; c = (int)Math.Sqrt(n) + 1;
            while (b < c)
            {
                if ((n % b) == 0)
                {
                    if (n / b * b - n == 0)
                    {
                        lis.Add(b);
                        n = n / b;
                        c = (int)Math.Sqrt(n) + 1;
                    }
                    else
                        b += 2;
                }
                else
                    b += 2;
            }
            lis.Add(n);
            return lis;
        }
        public List<int> GetObshMn(int a, int b)
        {
            List<int> la = GetProstDelit(a);
            List<int> lb = GetProstDelit(b);
            List<int> result = new List<int>();
            foreach (var item in la)
            {
                if (lb.IndexOf(item) >= 0)
                {
                    result.Add(item);
                    lb.Remove(item);
                }
            }
            return result;
        }
        public void SetDrob(int NewP, int NewQ)
        {
            bool accept = true;
            
            if (changable)
                if (NewP != P || NewQ != Q)
                {int pp = P;
                    int qq = Q;
                    if (OnChanging != null) accept = OnChanging(this,new DrobArgs(P,Q));
                    if (accept)
                    if (NewQ != 0)
                    {
                        Normalization(ref NewP, ref NewQ);
                        _p = NewP;
                        _q = NewQ;
                        simple = Math.Abs(P) < Math.Abs(Q);
                    }
                    else
                    {
                        _p = NewP;
                        _q = 1;
                        simple = Math.Abs(P) < Math.Abs(Q);
                        if (OnZero != null) OnZero(this, new DrobArgs(pp, qq));
                    }
                    if (OnChange != null) OnChange(this, new EventArgs());
                    
                }
        }
        public ObDrob(string aName,ChangeHandler ch,ChangingHandler ching,ZeroHandler zh)
        {
            changable = true;
            OnChanging = ching;
            _name = aName;
            OnChange = ch;
            OnZero = zh;
            SetDrob(1, 1);
        }
        public override string ToString()
        {
            return string.Format("Дробь {0,5} = {1,5}/{2,-5} = {3,-8:F3}", Name, P, Q, Value);
        }
        public void Swap()
        {
            SetDrob(Q, P);
        }
        public void Add (ObDrob a)
        {
            SetDrob(P * a.Q + a.P * Q, Q * a.Q);
        }
        public void Sub(ObDrob a)
        {
            SetDrob(P * a.Q - a.P * Q, Q * a.Q);
        }
        public void Mult(ObDrob a)
        {
            SetDrob(P * a.P, Q * a.Q);
        }
        public void Div(ObDrob a)
        {
            SetDrob(P * a.Q , Q * a.P);
        }
        public void Assign(ObDrob a)
        {
            SetDrob(a.P, a.Q);
            changable = a.Changable;
        }
        public int Compare(ObDrob a)
        {
            if (a != null)
                if ((P == a.P) & (Q == a.Q))
                {
                    return 0;
                }
                else
                    if (Value > a.Value) return 1;
                else return -1;
            else return 0;
        }
    }
}
