﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Drob
{
    /*
     _______________________________________________________
     |                                                     |
     |    мне лень менять названия элементов управления    |
     |    на более понятные, поэтому напротив методов      |
     |    буду коменты, поясняющие что это                 |
     |_____________________________________________________|
         
  */
    public partial class Form1 : Form
    {
        ObDrob a, b;
        public Form1()
        {
            InitializeComponent();
            a = new ObDrob("A", AChange,AChanging, ZeroEvent);
            b = new ObDrob("B", BChange, BChanging, ZeroEvent);
        }
        void ZeroEvent(ObDrob sender, DrobArgs e) //зероивент
        {
            if (MessageBox.Show("Дробь " + sender.Name + " получила нулевой знаменатель," +
                "\nкоторый был заменён единицей.\n\n Восстановить прежнее значение дроби?",
                "Обнуление знаменателя", MessageBoxButtons.YesNo) == DialogResult.Yes)
                sender.SetDrob(e.OldP, e.OldQ);
        }
        void AChange(ObDrob sender,EventArgs e) //происходит после смены А
        {
            groupBox1.Text = sender.Name;
            textBox1.Text = sender.P.ToString();
            textBox2.Text = sender.Q.ToString();
            textBox3.Text = sender.Value.ToString();
            checkBox1.Checked = sender.Changable;
            label8.Text = "Simple " + sender.Simple.ToString();
            label7.Text = "Compare "+ sender.Compare(b);
        }
        void BChange(ObDrob sender, EventArgs e)//происходит после смены B
        {
            groupBox2.Text = sender.Name;
            textBox6.Text = sender.P.ToString();
            textBox5.Text = sender.Q.ToString();
            textBox4.Text = sender.Value.ToString();
            checkBox2.Checked = sender.Changable;
            label9.Text = "Simple " + sender.Simple.ToString();
            label10.Text = "Compare " + sender.Compare(a);
        }
        bool AChanging(ObDrob sender,DrobArgs e)//происходит до замены А
        {
            bool Accept = true;
            int p, q;
            Accept = ((int.TryParse(textBox1.Text, out p)) & (int.TryParse(textBox2.Text, out q))&(Math.Abs(p)<100)& (Math.Abs(q) < 100)) ;
            if (!Accept) { MessageBox.Show("Параметры P или Q по модулю больше 100"); sender.SetDrob(e.OldP, e.OldQ); }
            return Accept;
        }
        bool BChanging(ObDrob sender, DrobArgs e)//происходит до замены B
        {
            bool Accept = true;
            int q,p;
            int.TryParse(textBox6.Text, out p);
            Accept = (int.TryParse(textBox5.Text, out q));
            Accept = Accept & (q % 2 == 1);
            if (!Accept) { MessageBox.Show("Знаменатель B кратен 2"); sender.SetDrob(e.OldP, e.OldQ); }
            return Accept;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)//это а.р
        {
            int x;
            if (int.TryParse(textBox1.Text,out x))
            {
                if (a != null) a.P = x;
            }
            else AChange(a, new EventArgs());
        }

        private void textBox2_TextChanged(object sender, EventArgs e)//это а.q
        {
            int x;
            if (int.TryParse(textBox2.Text, out x))
            {
                if (a != null) a.Q = x;
            }
            else AChange(a, new EventArgs());
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)//это а.value
        {
            if (e.KeyChar == (char)13)
            {
                double x;
                if (double.TryParse(textBox3.Text,out x))
                {
                    if (a != null) a.Value = x;
                }
            }
            else AChange(a, new EventArgs());
        }
        private void textBox6_TextChanged(object sender, EventArgs e)//это b.p
        {
            int x;
            if (int.TryParse(textBox6.Text, out x))
            {
                if (b != null) b.P = x;
            }
            else BChange(b, new EventArgs());
        }

        private void textBox5_TextChanged(object sender, EventArgs e)//это b.q
        {
            int x;
            if (int.TryParse(textBox5.Text, out x))
            {
                if (b != null) b.Q = x;
            }
            else BChange(b, new EventArgs());
        }
        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)//это b.value
        {
            if (e.KeyChar == (char)13)
            {
                double x;
                if (double.TryParse(textBox4.Text, out x))
                {
                    if (b != null) b.Value = x;
                }
            }
            else BChange(b, new EventArgs());
        }
        private void button1_Click(object sender, EventArgs e)//меняем местами а
        {
            a.Swap();
        }
        private void button2_Click(object sender, EventArgs e)//а +
        {
            a.Add(b);
        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
           
        }
        private void button4_Click(object sender, EventArgs e)//инфо о b
        {
            MessageBox.Show(b.ToString(), "Info");
        }

        private void button7_Click(object sender, EventArgs e)//а *
        {
            a.Mult(b);
        }

        private void button8_Click(object sender, EventArgs e)//а -
        {
            a.Sub(b);
        }

        private void button9_Click(object sender, EventArgs e)//а /
        {
            a.Div(b);
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)//разрешение на изменение a
        {
            if (a != null) a.Changable = checkBox1.Checked;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)//разрешение на изменение a
        {
            if (b != null) b.Changable = checkBox2.Checked;

        }

        private void button13_Click(object sender, EventArgs e)//ассигн а
        {
            if (a!=null)
            a.Assign(b);
        }

        private void button14_Click(object sender, EventArgs e)//ассишн b
        {
            if (b != null)
                b.Assign(a);
        }

        private void button6_Click(object sender, EventArgs e)//swap b
        {
            b.Swap();
        }

        private void button11_Click(object sender, EventArgs e)//b *
        {
            b.Mult(a);
        }

        private void button10_Click(object sender, EventArgs e)// b -
        {
            b.Sub(a);
        }

        private void button12_Click(object sender, EventArgs e)//b /
        {
            b.Div(a);
        }

        private void button3_Click(object sender, EventArgs e)//инфо о а
        {
            MessageBox.Show(a.ToString(), "Info");
        }
    }
}
