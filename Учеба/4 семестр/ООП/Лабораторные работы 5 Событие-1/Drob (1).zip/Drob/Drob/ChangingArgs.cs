﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drob
{
    class ChangingArgs : EventArgs
    {
        public bool AcceptChanging { get; set; }
        public int NewP { get; set; }
        public int NewQ { get; set; }
        public ChangingArgs(int NewP,int NewQ)
        {
            AcceptChanging = true;
            this.NewP = NewP;
            this.NewQ = NewQ;
            
        }
    }
}
