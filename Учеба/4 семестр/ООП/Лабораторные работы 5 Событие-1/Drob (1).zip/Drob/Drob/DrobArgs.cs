﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drob
{
    class DrobArgs : EventArgs
    {
        public int OldP { get; set; }
        public int OldQ { get; set; }
        public DrobArgs(int OldP,int OldQ)
        {
            this.OldP = OldP;
            this.OldQ = OldQ;
        }
    }
   
}
