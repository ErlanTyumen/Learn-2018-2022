﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    class Node<T> : IComparable
    {
        public Node<T> Next;
        public T Value;
        public Node(T obj)
        {
            Next = null;
            Value = obj;
        }
        public int CompareTo(object obj)
        {
            Node<T> node = (Node<T>)obj;
            return this.Value.ToString().CompareTo(node.Value.ToString());
        }
    }
}
