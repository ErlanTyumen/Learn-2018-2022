﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    abstract class Person
    {
        public string FIO { get { return fio; } private set { fio = value; } }
        public int Age
        {
            get { return age; }
            private set
            {
                if (value > 0 && value < 121)
                    age = value;
            }
        }
        public string Gender { get { return gender; } private set { gender = value; } }
        string fio;
        int age;
        string gender;
        int HoursHobbies;
        NewList<Hobby> hobbies;
        public Person()
        {
            hobbies = new NewList<Hobby>();
        }
        public Person(string FIO, string Gender, int Age)
        {
            this.FIO = FIO;
            this.Gender = Gender;
            if (Age > 0)
                this.Age = Age;
            else this.Age = 0;
            hobbies = new NewList<Hobby>();
            HoursHobbies = 0;
        }
        public Person(Person person)
        {
            this.FIO = person.FIO;
            this.Gender = person.Gender;
            this.Age = person.Age;
            hobbies = person.GetHobbies();
            HoursHobbies = 0;
            for (int i = 0; i < hobbies.Count; i++)
            {
                HoursHobbies += hobbies[i].TimeInDay;
            }
        }
        public string InputHobbies()
        {
            string str = "";
            for (int i = 0; i < hobbies.Count; i++)
            {
                str+=string.Format(i + "{0} time: {1} hours \n", hobbies[i].Name, hobbies[i].TimeInDay);
            }
            return str;
        }
        public NewList<Hobby> GetHobbies()
        {
            return hobbies;
        }
        public void AddHobby(Hobby hobby)
        {
            if (HoursHobbies+hobby.TimeInDay <= 24)
            {
                HoursHobbies += hobby.TimeInDay;
                hobbies.Add(hobby);
            }
        }
        public void RemoveHobby(int index)
        {
            if (index<hobbies.Count && index >=0)
            {
                HoursHobbies -= hobbies[index].TimeInDay;
                hobbies.RemIndex(index);
            }
        }
        public void NextYear()
        {
            Age++;
        }
        abstract public string InputInfo();
        public override string ToString()
        {
            if (this.GetType()!=typeof(Person) )
                return InputInfo();
            return string.Format(fio + "Gender: {0} Age: {1} CountHobbies: {2}    Type:{3}", gender, age, hobbies.Count,this.GetType());
        }
    }
}
