﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class StudentB : Person, IStudent , ICloneable
    {
        int course;
        bool isstudy;
        NewList<string> debts;
        public bool IsStudy
        {
            get { return isstudy; }
        }
        public int Course
        {
            get { return course; }
            set
            {
                if (value > 0 && value < 2)
                {
                    course = value;
                }
                else
                    isstudy = false;
            }
        }
        public StudentB()
        {

        }
        public StudentB(string fio,string gender,int age, int course) :base(fio,gender,age)
        {
            Course = course;
            debts = new NewList<string>();
        }
        public StudentB(Person ps):base(ps)
        {
            if (ps.GetType().GetInterfaces().Contains(typeof(IStudent)))
            {
                this.debts = (ps as IStudent).GetDebts();
                course = (ps as IStudent).Course;
                isstudy = (ps as IStudent).IsStudy;
            }
            else
            {
                debts = new NewList<string>();
            }
        }
        public void NexCourse()
        {
            if (isstudy)
            {
                Course++;
                if (debts.Count != 0) isstudy = false;
            }
        }
        public void InputDebts()
        {
            Console.WriteLine("Долги студента B");
            for (int i = 0; i < debts.Count; i++)
            {
                Console.Write("{0} ", debts[i]);
            }
        }
        public void AddDebts(string name)
        {
            if (isstudy)
                debts.Add(name);
        }
        public void RemDebts(string name)
        {
            if (isstudy)
                debts.RemValue(name);
        }
        override public string InputInfo()
        {
            NewList<Hobby> hobbies = GetHobbies();
           return string.Format(FIO + " StudentB, Gender: {0} Age: {1} CountHobbies: {2} debtsCount: {3} isstudy:{4}", Gender, Age, hobbies.Count, debts.Count, isstudy);
        }
        public void KolMet() { Console.WriteLine("StudB"); }
        public NewList<string> GetDebts() => debts;
        public object Clone() =>new StudentB(this);
    }
}
