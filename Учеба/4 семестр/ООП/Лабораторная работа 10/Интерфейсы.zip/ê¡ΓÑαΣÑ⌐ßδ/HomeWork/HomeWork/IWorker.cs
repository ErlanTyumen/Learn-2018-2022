﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    interface IWorker
    {
        int HoursInDay { get; set; }
        string Job { get; }
        void Work();
        void NewJob(string job);
        void KolMet();
    }
}
