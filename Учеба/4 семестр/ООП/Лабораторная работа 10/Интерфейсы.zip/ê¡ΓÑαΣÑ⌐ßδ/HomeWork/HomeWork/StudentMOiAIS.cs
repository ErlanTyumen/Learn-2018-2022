﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace HomeWork
{
    class StudentMOiAIS : Person, IStudent ,ICloneable
    {
        //студенты могут быть только от 18 
        NewList<string> debts;
        int course;
        public int Course
        {
            get { return course; }
            set
            {
                if (value > 0 && value < 5)
                {
                    course = value;
                }
                else
                    isstudy = false;
            }
        }
        bool isstudy;
        public bool IsStudy
        {
            get {return isstudy; }
        }
        public StudentMOiAIS() { }
        public StudentMOiAIS(string FIO,string Gender,int Age,int course) : base(FIO,Gender,Age)
        {
            if (Age < 18)
                new IndexOutOfRangeException();
            Course = course;
            debts = new NewList<string>();
        }
        public StudentMOiAIS(Person ps) : base(ps)
        {
            if ((ps.GetType().GetInterfaces().Contains(typeof(IStudent))))
            {
                this.debts = (ps as IStudent).GetDebts();
                course = (ps as IStudent).Course;
                isstudy = (ps as IStudent).IsStudy;
            }
            else
            {
                debts = new NewList<string>();
            }
        }
        public void NexCourse()
        {
            if (isstudy)
            {
                Course++;
                if (debts.Count != 0) isstudy = false;
            }
        }
        public void InputDebts()
        {
            Console.WriteLine("Долги студента MOiAIS");
            for (int i = 0; i < debts.Count; i++)
            {
                Console.Write("{0} ", debts[i]);
            }
        }
        public void AddDebts(string name)
        {
            debts.Add(name);
        }
        public void RemDebts(string name)
        {
            if (isstudy)
                debts.RemValue(name);
        }
        override public string InputInfo()
        {
            NewList<Hobby> hobbies = GetHobbies();
           return string.Format(FIO + " Student, Gender: {0} Age: {1} CountHobbies: {2} debtsCount: {3} isstudy:{4} ", Gender, Age, hobbies.Count,  debts.Count,isstudy);
        }
        public void MetStudB()
        {
            Console.WriteLine("Метод студента B");
        }
        public void KolMet() { Console.WriteLine("StudA"); }
        public NewList<string> GetDebts() => debts;
        public object Clone()
        {
            return new StudentMOiAIS(this);
        }
    }
}
