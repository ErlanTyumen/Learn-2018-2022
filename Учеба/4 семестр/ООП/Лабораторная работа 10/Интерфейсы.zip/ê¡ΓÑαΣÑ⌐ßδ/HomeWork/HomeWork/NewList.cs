﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    class NewList<T> //этот класс оборачивает собой класс mylistt. Это сделано для того,
        //чтобы исключить появления Node<T>, и сразу работать со значениями
    {
        public NewList()
        {
        }
        MyList<T> list = new MyList<T>();
        public IEnumerator<T> GetEnumerator()
        {
            return new ListEnumerator<T>(list);
        }
        public int Count
        {
            get { return list.Count; }
        }
        public T this[int index]
        {
            get
            {
                if (!(index<list.Count || index>=0))
                    throw new StackOverflowException();
                return list[index].Value;
            }
            set
            {
                if (!(index < list.Count || index >= 0))
                    throw new StackOverflowException();
                list[index].Value = value;
            }
        }
        public void Add(T value)
        {
            list.AddNode(new Node<T>(value));
        }
        public void RemIndex(int index)
        {
            list.RemoveNode(index);
        }
        public void RemValue(T value)
        {
            list.RemoveNode(new Node<T>(value));
        }
        public int GetPosition(T value)
        {
            return list.Find(new Node<T>(value));
        }
        public void Sort()
        {
            list.quicksort();
        }
    }
}
