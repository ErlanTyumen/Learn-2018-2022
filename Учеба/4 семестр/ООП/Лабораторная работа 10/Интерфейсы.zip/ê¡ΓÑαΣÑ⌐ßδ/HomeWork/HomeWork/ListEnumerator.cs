﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    class ListEnumerator<T> : IEnumerator<T>
    {
        MyList<T> list;
        int position = -1;
        public ListEnumerator(MyList<T> list)
        {
            this.list = list;
        }
        public T Current
        {
            get
            {
                if (position == -1 || position >= list.Count)
                    throw new StackOverflowException();
                return list[position].Value;
            }
        }

        object IEnumerator.Current
        {
            get
            {
                if (position == -1 || position >= list.Count)
                    throw new StackOverflowException();
                return list[position].Value;
            }
        }

        T IEnumerator<T>.Current
        {
            get
            {
                if (position == -1 || position >= list.Count)
                    throw new StackOverflowException();
                return list[position].Value;
            }
        }
        public bool MoveNext()
        {
            if (position < list.Count - 1)
            {
                position++;
                return true;
            }
            else
                return false;
        }

        public void Reset()
        {
            position = -1;
        }

        void IDisposable.Dispose()
        {
          
        }

        bool IEnumerator.MoveNext()
        {
            return MoveNext();
        }

        void IEnumerator.Reset()
        {
            Reset();
        }
    }
}
