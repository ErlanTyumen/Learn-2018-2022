﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    class MyList<T>
    {
        //Этот список, хранящий в себе ноды реально работает!
        //да я красавчег
        Node<T> Head; //можно делать и без Node, но я не хочу, мне лень(
        public int Count { get { return count; } private set { count = value; } }
        int count = 0;
        public MyList()
        {
            Head = null;
            Count = 0;
        }
        public Node<T> this[int index]
        {
            get
            {
                if ((index > Count || index < 0))
                    throw new StackOverflowException();
                if (index == 0)
                    return Head;
                
                    Node<T> node = Head;
                    for (int i = 0; i < index; i++)
                    {
                        node = node.Next;
                    }
                    return node;
            }
            set
            {
                if ((index > Count || index < 0))
                    throw new StackOverflowException();
                if (index == 0)
                {
                    value.Next = null;
                    Head = value;
                }
                else
                {
                    Node<T> node = Head;
                    for (int i = 1; i < index; i++)
                    {
                        node = node.Next;
                    }
                    node.Value = value.Value;
                }
            }
        }
        public void AddNode(Node<T> node)
        {
            if (Head == null)
            {
                Head = node;
                Count = 1;
            }
            else
            {
                this[Count - 1].Next = node;
                Count = Count + 1;
            }
        }
        public void RemoveNode(int index)
        {
            if (index > Count - 1 || index < 0)
                throw new StackOverflowException();
                if (index == 0)
                    Head = Head.Next;
                else
                if (index == Count - 1)
                    this[Count - 2].Next = null;
                else
                    this[index - 1].Next = this[index + 1];
                Count--;
            
        }
        public void RemoveNode(Node<T> node)
        {
            RemoveNode(Find(node));
        }
        public void Input()
        {
            for (int i = 0; i < Count; i++)
            {
                Console.Write("{0} ", this[i]);
            }
        }
        public void RemoveAll()
        {
            Head = null;
            Count = 0;
        }
        public int Find(Node<T> node)
        {
            for (int i = 0; i < Count-1; i++)
            {
                if (this[i].CompareTo(node) == 0)
                    return i;
            }
            return -1;
        }
        private int partition(int a, int b)
        {
            int i = a;
            for (int j = a; j <= b; j++)         // просматриваем с a по b
            {
                if (this[j].CompareTo(this[b]) <= 0)  // если элемент [j] не превосходит [b],
                {
                    T t = this[i].Value;                  // меняем местами [j] и [a], [a+1], [a+2] и так далее...
                    this[i].Value = this[j].Value;                 // то есть переносим элементы меньшие [b] в начало,
                    this[j].Value = t;                    // а затем и сам [b] «сверху»
                    i++;                         // таким образом последний обмен: [b] и [i], после чего i++
                }
            }
            return i - 1;                        // в индексе i хранится <новая позиция элемента m[b]> + 1
        }
        public void quicksort(int left, int right)// a - начало подмножества, b - конец
        {                                        // для первого вызова: a = 0, b = <элементов в массиве> - 1
            if (left >= right) return;
            int c = partition(left, right);
            quicksort( left, c - 1);
            quicksort( c + 1, right);
        }
        public void quicksort()
        {
            quicksort(0, count - 1);
        }
    }
}
