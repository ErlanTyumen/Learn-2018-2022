﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class WorkerB : Person, IWorker ,ICloneable
    {
        public WorkerB()
        {

        }

        public WorkerB(Person person) : base(person)
        {
            if (person.GetType().GetInterfaces().Contains(typeof(IWorker)))
            {
                HoursInDay = (person as IWorker).HoursInDay;
                job = (person as IWorker).Job;
                hours = (person as IWorker).HoursInDay;
            }
        }

        public WorkerB(string fio, string gender, int age) : base(fio, gender, age)
        {
            if (age < 40) throw new IndexOutOfRangeException();
        }
        int hours;
        string job;
        //тут мы говорим что хобби важнее работы
        public int HoursInDay
        {
            get { return hours; }
            set
            {
                int h = 0;
                NewList<Hobby> hob = GetHobbies();
                foreach (var item in hob)
                {
                    h += item.TimeInDay;
                }
                if (h + value <= 24)
                    hours = value;
                else
                    hours = value - h;
            }
        }

        public string Job { get { return job; } }

        public override string InputInfo()
        {
            string str = string.Format(FIO + " gender: {0} age: {1} Job: {2} hoursWorking: {3} Hobbies:", Gender, Age, job, hours);
            str += "\n";
            str += InputHobbies();
            return str;
        }

        public void NewJob(string j)
        {
            if (job.CompareTo(j) != 0)
                job = j;
        }

        public void Work()
        {
            Console.WriteLine("Рабочий B пошёл на работу " + job);
        }
        public void KolMet() { Console.WriteLine("рабB"); }

        public object Clone()
        {
            return new WorkerB(this);
        }
    }
}
