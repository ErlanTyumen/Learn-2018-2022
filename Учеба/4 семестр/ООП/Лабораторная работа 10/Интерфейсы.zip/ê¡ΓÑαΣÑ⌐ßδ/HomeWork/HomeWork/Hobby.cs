﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    class Hobby
    {
        public string Name { get; private set; }
        public int TimeInDay
        {
            get { return time; }
            set
            {
                if (value >= 0 && value<=24)
                {
                    time = value;
                } 
            }
        }
        private int time;
        public Hobby(string name,int timeinday)
        {
            Name = name;
            if (timeinday >= 0 && timeinday <= 24)
                time = timeinday;
            else
                time = 0;

        }
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
