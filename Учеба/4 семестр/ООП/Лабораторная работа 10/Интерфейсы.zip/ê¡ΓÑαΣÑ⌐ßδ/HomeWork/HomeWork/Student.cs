﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    class Student
    {
        IStudent student;
        public Student(IStudent stud)
        {
            student = stud;
        }
        public void Info()
        {
            Console.WriteLine(student.InputInfo());
            student.InputDebts();
            Console.WriteLine();
        }
        public void GenerateRandomDeb(int count)
        {
            for (int i = 0; i < count; i++)
            {
                student.AddDebts(new Random().Next(24/count).ToString());
            }
        }
    }
}
