﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class WorkerA:Person,IWorker ,ICloneable //коллизия есть. 
       /* В интерфейсе Iworker и в классе Person есть общий метод инпутинфо.
        И по идее мы должны реализовывать этот метод для iworker и person отдельно. 
        Но просто перекрыв метод от Person мы тем самым реализовываем его и для Iworker.
        крч, проблема колизии решена. как - сложно объяснить*/
    {

        public WorkerA()
        {

        }

        public WorkerA(Person person) : base(person)
        {
            if (person.GetType().GetInterfaces().Contains(typeof(IWorker)))
            {
                HoursInDay = (person as IWorker).HoursInDay;
                job = (person as IWorker).Job;
            }
        }

        public WorkerA(string fio,string gender,int age):base(fio,gender,age)
        {
            if (age < 18) throw new IndexOutOfRangeException();
        }
        int hours;
        string job;
        //тут мы говорим что хобби важнее работы
        public int HoursInDay { get { return hours; } set {
                int h = 0;
                NewList<Hobby> hob = GetHobbies();
                foreach (var item in hob)
                {
                    h += item.TimeInDay;
                }
                if (h + value <= 24)
                    hours = value;
                else
                    hours = value - h;
            }
        }

        public string Job { get { return job; } }
        public void NewJob(string j)
        {
            if (job.CompareTo(j)!=0)
            job = j;
        }

        public void Work()
        {
            Console.WriteLine("Рабочий А пошёл на работу " + job);
        }

        public override string InputInfo()
        {
            string str = string.Format(FIO + " gender: {0} age: {1} Job: {2} hoursWorking: {3} Hobbies:",Gender,Age,job,hours);
            str += "\n";
            str+=InputHobbies();
            return str;
        }
        public void KolMet() { Console.WriteLine("рабА"); }
        public object Clone()
        {
            return new WorkerA(this);
        }
    }
}
