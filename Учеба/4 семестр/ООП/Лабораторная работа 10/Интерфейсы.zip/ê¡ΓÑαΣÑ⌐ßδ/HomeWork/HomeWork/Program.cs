﻿using System;
using System.Linq;

namespace HomeWork
{
    class Program
    {
        static void Main(string[] args)
        {
            StudentB StB1 = new StudentB("StudB1", "М", 20, 2);
            StudentB StB2 = new StudentB("StudB2", "Ж", 18, 2);
            StudentMOiAIS StMO1 = new StudentMOiAIS("StudMO1", "M", 25, 4);
            StudentMOiAIS StMO2 = new StudentMOiAIS("StudMO2", "Ж", 65, 3);
            Student stud = new Student(new StudentMOiAIS("StudMO3", "М", 25, 4));
            StudentAndWorker stwo = new StudentAndWorker("StudWorker", "Ж", 25, 4);
            stud.GenerateRandomDeb(3);
            WorkerA woA = new WorkerA("WorkA", "М", 25);
            WorkerB woB = new WorkerB("WorkB", "Ж", 50);
            NewList<Person> persons = new NewList<Person>();
            persons.Add(StB1);
            persons.Add(StB2);
            persons.Add(StMO1);
            persons.Add(StMO2);
            // persons.Add(stud); мы не можем его добавить, потому-что stud не является наследником person
            persons.Add(stwo);
            persons.Add(woA);
            persons.Add(woB);
            
            foreach (var item in persons) //добавили всем хобби, как видно foreach работает для ноовго списка
            {
                for (int i = 0; i < 2; i++)
                {
                    string str = string.Format("{0} hobby {1}", item.FIO, i);
                    Hobby hob = new Hobby(str, new Random().Next(3));
                    item.AddHobby(hob);
                }
            }
            foreach (var item in persons) // вывели краткуюинфу
            {
                Console.WriteLine(item);
            }
            Console.WriteLine();
            persons.Sort();//отсортировали нах
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("Выводим список хобби вообще всех");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.Black;
            foreach (var item in persons) // вывели краткуюинфу
            {
                Console.WriteLine(item.InputHobbies());
            }
            NewList<IStudent> students = new NewList<IStudent>();
            foreach (var item in persons) //делаем новый список, в котором все люди - студенты
            {
                Random random = new Random();
                switch (random.Next(0,2))
                {
                    case 0:
                        students.Add(new StudentAndWorker(item));
                        break;
                    case 1:
                        students.Add(new StudentMOiAIS(item));
                        break;
                    default:
                        students.Add(new StudentB(item));
                        break;
                }
            }
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("Выводим список всех людей, являющихся студентами");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.Black;
            foreach (var item in persons)
            {
                if (item.GetType().GetInterfaces().Contains(typeof(IStudent)))
                    Console.WriteLine(item);
            }
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("Выводим список всех людей, превращенных в студентов");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.Black;
            foreach (var item in students) // вывели краткуюинфу
            {
                Console.WriteLine(item);
            }
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("Выводим список всех людей, являющихся рабочими");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.Black;
            foreach (var item in persons)
            {
                if (item.GetType().GetInterfaces().Contains(typeof(IWorker)))
                    Console.WriteLine(item);
            }
            Console.ForegroundColor = ConsoleColor.Black;
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("Вы могли заметить, что при выводе рабочих выводятся ещё и их хобби\nвот в этом и заключается отличие:D");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.BackgroundColor = ConsoleColor.Black;
            Console.WriteLine("Но у нас ещё есть stud, который нигде не выводился.\n А почему? Потому-что он принадлежит классу Student. \nОн не наследует Person");
            Console.WriteLine("Он спокойно генерирует объект по конструктору класса, \nявляющимся наследником интерфейса IStident\nВот он:");
            Console.WriteLine(stud);
            Console.WriteLine("Да, у него нет метода, переопределяющего tostring. \nУ него есть другой метод, Info:");
            Console.WriteLine();
            stud.Info();
            Console.WriteLine();
            Console.WriteLine("А ещё у него единственного есть метод, генерирующий долги ._.");
            Console.WriteLine("переменная stud является переменной типа Student в которой совсем другие методы\nда и вообще она совсем другая\nНо она строится по конструктору класса, наследуемого IStudent, однако сама она не наследует этот интерфейс");
        }
    }
}
