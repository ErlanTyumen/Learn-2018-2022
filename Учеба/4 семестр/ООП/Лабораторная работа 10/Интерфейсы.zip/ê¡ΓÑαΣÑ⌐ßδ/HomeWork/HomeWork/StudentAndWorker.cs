﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HomeWork
{
    class StudentAndWorker : Person, IStudent, IWorker,ICloneable
    {
        NewList<string> debts;
        public StudentAndWorker()
        {
        }

        public StudentAndWorker(Person person) : base(person)
        {
            if (person.GetType().GetInterfaces().Contains(typeof(IWorker)))
            {
                hours = (person as IWorker).HoursInDay;
                job = (person as IWorker).Job;
                if (person.GetType().GetInterfaces().Contains(typeof(IStudent)))
                {
                    course = (person as IStudent).Course;
                    isstudy = (person as IStudent).IsStudy;
                    debts = (person as IStudent).GetDebts();
                }
                else
                {
                    course = 1;
                    isstudy = true;
                    debts = new NewList<string>();
                }
            }
            if (person.GetType().GetInterfaces().Contains(typeof(IStudent)))
            {
                course = (person as IStudent).Course;
                isstudy = (person as IStudent).IsStudy;
                debts = (person as IStudent).GetDebts();
                if (person.GetType().GetInterfaces().Contains(typeof(IWorker)))
                {
                    hours = (person as IWorker).HoursInDay;
                    job = (person as IWorker).Job;
                }
                else
                {
                    hours = 0;
                    job = "NS";
                }
            }
        }

        public StudentAndWorker(string FIO, string Gender, int Age,int course) : base(FIO, Gender, Age)
        {
            Course = course;
            if (Age < 18) throw new IndexOutOfRangeException();
            debts = new NewList<string>();
        }
        int course;
        public int Course { get => course; set
            {
                if (value > 0 && value < 3)
                {
                    course = value;
                }
                else
                    isstudy = false;
            }
        }
        bool isstudy;
        public bool IsStudy => isstudy;

        int hours;
        public int HoursInDay { get { return hours; } set {
                int h = 0;
                NewList<Hobby> hob = GetHobbies();
                foreach (var item in hob)
                {
                    h += item.TimeInDay;
                }
                if (h + value <= 24)
                    hours = value;
                else
                    hours = value - h;
            } }

        string job;
        public string Job { get { return job; }  }

        public void AddDebts(string name)
        {
            if (isstudy)
                debts.Add(name);
        }

        public void InputDebts()
        {
            Console.WriteLine("Долги студента B");
            for (int i = 0; i < debts.Count; i++)
            {
                Console.Write("{0} ", debts[i]);
            }
        }

        public override string InputInfo()
        {
            NewList<Hobby> hobbies = GetHobbies();
            return string.Format(FIO + " Student and Worker, Gender: {0} Age: {1} CountHobbies: {2} debtsCount: {3} isstudy:{4} Job: {5}", Gender, Age, hobbies.Count, debts.Count, isstudy,job);
        }

        public void KolMet()//а вот и колизия
        {
            Console.WriteLine("метод колизии");
        }

        public void NewJob(string job)
        {
            this.job = job;
        }

        public void NexCourse()
        {
            if (isstudy)
            {
                Course++;
                if (debts.Count != 0) isstudy = false;
            }
        }

        public void RemDebts(string name)
        {
            if (isstudy)
                debts.RemValue(name);
        }

        public void Work()
        {
            Console.WriteLine("Студент раб. пошел на работу " + job);
        }
        public NewList<string> GetDebts() => debts;
        public object Clone() => new StudentAndWorker(this);
    }
}
