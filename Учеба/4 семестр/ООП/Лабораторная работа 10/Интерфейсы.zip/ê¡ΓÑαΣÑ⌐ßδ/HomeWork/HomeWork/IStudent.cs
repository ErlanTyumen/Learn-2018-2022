﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HomeWork
{
    interface IStudent
    {
        int Course { get; set; }
        bool IsStudy { get; }
        void NexCourse();
        void InputDebts();
        void AddDebts(string name);
        void RemDebts(string name);
        NewList<string> GetDebts(); 
        string InputInfo();
        void KolMet();
    }
}
