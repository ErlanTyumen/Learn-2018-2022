﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Интерфейс1
{
    abstract class Animal
    {
        abstract public void Eat(Animal a);
        public Animal() { }
        
    }
}
