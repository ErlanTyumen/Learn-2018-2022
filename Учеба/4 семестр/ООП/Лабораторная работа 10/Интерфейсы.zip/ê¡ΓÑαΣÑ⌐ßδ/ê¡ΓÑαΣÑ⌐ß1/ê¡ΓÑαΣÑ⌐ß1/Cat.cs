﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Интерфейс1
{
    class Cat :  Animal  , Pet , CanMove //это зверь, который может двигаться
    {
        private int legs;
        public string Name { get; set; }
        public int Walk()
         {
             Console.WriteLine("Кошка {1} переместилось при помощи всех своих {0} лапок", legs,Name);
             return legs;
         }
        public Cat( string name) : base()
        {
            Name = name;
            legs = 4;
        }
        override public void Eat(Animal sp)
        {
            if (sp.GetType().Name == "Fish")
                Console.WriteLine("Кошка {0} съела Рыбу {1}", Name, (sp as Fish).Name);
            else
                if (sp.GetType().Name == "Spider")
                Console.WriteLine("Кошка {0} съела Паука", Name);
            else
            Console.WriteLine("Кошка {0} не может съесть {1}", Name, sp.GetType().Name);
        }

        public void Play()
        {
            Console.WriteLine("Вы поиграли с Кошкой {0}, она рада", Name);

        }
    }
}
