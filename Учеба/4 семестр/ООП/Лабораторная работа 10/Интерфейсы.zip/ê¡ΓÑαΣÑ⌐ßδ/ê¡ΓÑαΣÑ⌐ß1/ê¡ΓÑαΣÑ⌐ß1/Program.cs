﻿using System;

namespace Интерфейс1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Fish f = new Fish("f");
            Animal fa = new Fish("fa");
            Cat c = new Cat("Мускатный орех");
            Spider sp = new Spider();
            f.Eat(c);
            f.Eat(sp);
            f.Play();
            Console.WriteLine();
            c.Eat(fa);
            c.Eat(f);
            c.Play();
            c.Walk();
            Console.WriteLine();
            Console.WriteLine("Павук:");
            sp.Walk();
            sp.Eat(c);
        }
    }
}
