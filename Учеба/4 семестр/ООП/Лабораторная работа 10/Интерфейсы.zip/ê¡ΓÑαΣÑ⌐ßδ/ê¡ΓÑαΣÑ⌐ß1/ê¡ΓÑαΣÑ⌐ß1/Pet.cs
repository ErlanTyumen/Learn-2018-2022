﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Интерфейс1
{
    interface Pet
    {
        public string Name { get; set; }
        public void Play();
    }
}
