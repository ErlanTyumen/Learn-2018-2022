﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace Интерфейс1
{
    interface CanMove
    {
        private static int legs;
        int Legs { get { return legs; }private set { } }
        public int Walk()
       {
            Console.WriteLine("Животное переместилось при помощи всех своих {0} лапок", legs);
            return legs;
        }
       
    }
}
