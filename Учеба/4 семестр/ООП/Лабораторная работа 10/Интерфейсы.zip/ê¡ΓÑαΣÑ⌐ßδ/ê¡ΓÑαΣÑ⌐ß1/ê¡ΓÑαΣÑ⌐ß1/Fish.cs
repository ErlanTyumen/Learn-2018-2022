﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Интерфейс1
{
    class Fish : Animal , Pet
    {
        private string name;
        public string Name { get { return name; } set { } }
        public void Play() 
        {
            Console.WriteLine("Вы поиграли с рыбкой {0}, она рада", Name);
        }
        override public void Eat(Animal an)
        {
            if (an.GetType().Name == "Spider")
                Console.WriteLine("Рыбка {0} съела Паука", Name);
            else
                Console.WriteLine("Рыба {0} не может съесть {1}", Name, an.GetType().Name);
            Console.WriteLine();
        }
        public Fish(string name) : base()
        {
            this.name = name;
        }
    }
}
