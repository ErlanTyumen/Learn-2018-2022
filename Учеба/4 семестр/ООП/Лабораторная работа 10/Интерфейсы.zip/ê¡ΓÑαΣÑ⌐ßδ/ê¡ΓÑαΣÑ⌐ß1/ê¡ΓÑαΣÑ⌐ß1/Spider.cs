﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Интерфейс1
{
    class Spider : Animal , CanMove
    {
        public Spider() : base()
        {
        }
        public override void Eat(Animal an)
        {
            Console.WriteLine("Кого???? Паук никого не ест в этом мире!");
        }
        CanMove move;
        public int Walk()
        {
            Console.WriteLine("Павук переместился при помощи всех своих {0} лапок", 8);
            return 8;
        }
        

    }
}
