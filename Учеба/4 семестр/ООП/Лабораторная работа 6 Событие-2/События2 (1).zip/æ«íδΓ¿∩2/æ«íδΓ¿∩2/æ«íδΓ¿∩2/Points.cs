﻿using System;
using System.Collections.Generic;
using System.Text;

namespace События2
{
    class Points
    {
        /*
         _________________________________________
         |                                       |
         |            свойства   и поля          |
         |_______________________________________|
         */
        Point[] points ;
        public int length { get; private set; }
        public Point this[int i]
        {
            get
            {
                return points[i];
            }
            private set
            {
                points[i] = value;
            }
        }
        /*
        _________________________________________
        |                                       |
        |            события                    |
        |_______________________________________|
        */
        public delegate void ChangeHandler(Points sender, PointArgs e);
        public event ChangeHandler OnChange;
        /*
        _________________________________________
        |                                       |
        |         методы и конструкторы         |
        |_______________________________________|
        */
        public Points()
        {
            points = new Point[0];
            length = 0;
        }
        public Points(int N, Point.ChangingHandler ching,
            Point.ChangeHandler ch, Point.AxisHandler ax)
        {
            Random rnd = new Random();
            length = N;
            points = new Point[N];
            for (int i = 0; i < length; i++)
            {
                Point p = new Point("точка", rnd.Next(-10, 10), rnd.Next(-10, 10));
                p.OnAxis += ax;
                p.OnChange += ch;
                p.OnChanging += ching;
                SetPoint(i, p);
            }
        }
        private Point[] CloneMas(Point[] whatclone,Point[] mas)
        {
            if(mas.Length<=whatclone.Length)
            for (int i = 0; i < mas.Length; i++)
            {
                    mas[i] = whatclone[i];
            }
            else
                for (int i = 0; i < whatclone.Length; i++)
                {
                    mas[i] = whatclone[i];
                }
            return mas;
        }
        public void SetPoint(int i,Point p)
        {
            this[i] = p;
            PointArgs pa = new PointArgs(p.X, p.Y);
            pa.I = i;
            if (OnChange != null) OnChange(this, pa);
        }
        public void Add(Point p)
        {
            Point[] pmas = new Point[length + 1];
            length++;
            pmas = CloneMas(points, pmas);
            points = pmas;
            SetPoint(length-1, p);
        }
        public void Romove(int k)
        {
            Point[] pmas = new Point[length - 1];
            length--;
            pmas = CloneMas(points, pmas);
            points = pmas;
            for (int i = k+1; i < length; i++)
            {
                SetPoint(i - 1, this[i]);
            }
        }
    }
}
