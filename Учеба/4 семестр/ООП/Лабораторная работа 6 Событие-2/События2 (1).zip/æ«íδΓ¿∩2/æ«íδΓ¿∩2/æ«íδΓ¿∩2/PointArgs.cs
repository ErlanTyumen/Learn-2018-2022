﻿using System;
using System.Collections.Generic;
using System.Text;

namespace События2
{
    class PointArgs
    {
       public double X;
       public double Y;
        public int I;
        public PointArgs(double OldX, double OldY)
        {
            X = OldX;Y = OldY;
        }
    }
}
