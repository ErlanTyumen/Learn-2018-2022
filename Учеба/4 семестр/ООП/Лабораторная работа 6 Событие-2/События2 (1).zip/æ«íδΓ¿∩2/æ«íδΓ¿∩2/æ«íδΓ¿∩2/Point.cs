﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Text;

namespace События2
{
    class Point
    {
         /*
         _________________________________________
         |                                       |
         |            свойства   и поля          |
         |_______________________________________|
         */
        public string Name { get; private set; }
        double _x;
        double _y;
        public double X
        {
            get { return _x; }
            set
            {
                SetPoint(value, _y);
            }
        }
        public double Y
        {
            get { return _y; }
            set
            {
                SetPoint(_x, value);
            }
        }
        public int q { get; private set; }
        double _ro;
        public double ro
        {
            get { return _ro; }
            set
            {
                _ro = value;
                SetPoint(1, Math.Pow((value * value - 1), 1 / 2.0));
            }
        }
        /*
         _________________________________________
         |                                       |
         |            события                    |
         |_______________________________________|
         */
        public delegate bool ChangingHandler(Point sender, PointArgs e);
        public delegate void ChangeHandler(Point sender, EventArgs e);
        public delegate bool AxisHandler(Point sender, PointArgs e);
        public event ChangingHandler OnChanging;
        public event ChangeHandler OnChange;
        public event AxisHandler OnAxis;
        /*
        _________________________________________
        |                                       |
        |         методы и конструкторы         |
        |_______________________________________|
        */
        public Point(string name)
        {
            Name = name;
            X = 0;
            Y = 0;
        }
        public Point(string name,double X, double Y )
        {
            Name = name;
            this.X = X;
            this.Y = Y;
        }
        public void SetPoint(double NewX,double NewY)
        {
            double xx = _x;
            double yy = _y;
            bool accept = true;
            if (NewX != X || NewY != Y)
            {
                if (OnChanging != null)
                    accept = OnChanging(this, new PointArgs(xx, yy));
                if (accept)
                {
                    bool accept2 = true;
                        if (OnAxis != null) accept2 = OnAxis(this, new PointArgs(xx, yy));
                    if (accept2)
                    {
                        _x = NewX;
                        _y = NewY;
                        setq();
                        setro();
                        if (OnChange != null) OnChange(this, new EventArgs());
                    }
                }
            }
        }
        public void SimOX()
        {
            SetPoint(_x, _y * (-1));
        }
        public void SimOY()
        {
            SetPoint(_x * (-1), _y);
        }
        public void SimO()
        {
            SetPoint(_x * (-1), _y * (-1));
        }
        public void MoveRel(double dx,double dy)
        {
            SetPoint(_x+dx,_y+dy);
        }
        public double RoFrom(Point p)
        {
            return Math.Pow((Math.Abs(X - p.X )* Math.Abs(X - p.X) + Math.Abs(Y- p.Y)* Math.Abs(Y - p.Y)), 1.0 / 2.0);
        }
        private void setq()
        {
            if ((_y != 0) & (_x != 0))
            {
                if (_x > 0)
                {
                    if (_y > 0) q = 1;
                    else q = 4;
                }
                else
                    if (_y > 0) q = 2;
                else q = 3;
            }
            else q = 0;
        }
        private void setro()
        {
            _ro = Math.Pow((_x * _x + _y * _y), 1 / 2.0);
        }
        public bool Equal(Point p)
        {
            return (p.X == X) & (p.Y == Y);
        }
        public override string ToString()
        {
            string str ="";
            str = Name + string.Format(" X: {0,3} Y: {1,3} q: {2,3} ro: {3}", Math.Truncate(X * 100) / 100, Math.Truncate(Y * 100) / 100, q, Math.Truncate(ro*100)/100);
            return str;
        }
    }
}
