﻿using System;
using System.Threading;

namespace События2
{
    class Program
    {
        static Random rnd = new Random();
        static void PChange(Point sender,EventArgs e)
        {
            Console.WriteLine(sender);
        }
        static bool PChanging(Point sender, PointArgs e)
        {
            bool accept = !((sender.Y > 8) | (sender.X > 8) | (sender.X < -8) | (sender.Y < -8));
            if (accept) { 
                sender.SetPoint(e.X, e.Y);
            }
            return accept;
        }
        static bool PAxis(Point sender, PointArgs e)
        {
            if ((sender.X == 0) | (sender.Y == 0))
            {
                sender.SetPoint(e.X, e.Y);
                return false;
            }
            return true;
        }
        static void PsChange1(Points sender, PointArgs e)
        {
            Point p = new Point("testingPoint", e.X, e.Y);
            int index = e.I;
            for (int i = 0; i < sender.length; i++)
            {
                if ((sender[i].RoFrom(p)<3)&(i!=index))
                {
                    double dx = rnd.NextDouble() + rnd.Next(-5, 4);
                    double dy = Math.Pow((25 - dx * dx), 1 / 2.0);
                    sender[i].MoveRel(dx, dy);
                }
            }
            Input(sender);
        }
        static void Input(Points points)
        {
            //Console.Write("{0,-30} {1,-4} {2,-4}");
            Console.Write("{0,-40} ", "Point");
            for (int i = 0; i < points.length; i++)
            {
                Console.Write("{0,-6}", i);
            }
            Console.WriteLine();
            for (int i = 0; i < points.length; i++)
            {
                Console.Write("{0,-40} ", points[i]);
                for (int j = 0; j < points.length; j++)
                {
                    Console.Write("{0,-6}", Math.Truncate((points[i].RoFrom(points[j]))*100)/100);
                }
                Console.WriteLine();
            }
        }
       
        static void Main(string[] args)
        {
            Console.WriteLine("Изначальные точки:");
                Console.WriteLine();
            Points points = new Points(5,PChanging,PChange,PAxis);
            points.OnChange += PsChange1;
            Input(points);
            Console.WriteLine();
            Console.WriteLine();
            Point p = new Point("Новая", 8, 2);
            p.OnAxis += PAxis;
            p.OnChange += PChange;
            p.OnChanging += PChanging;
            points.Add(p);
            Console.WriteLine();
            points.Romove(points.length - 1);
            Console.WriteLine("добавили и удалили точку");
            Input(points);
            for (int i = 0; i < points.length; i++)
            {
                double dx = rnd.NextDouble() + rnd.Next(-2,2);
                double dy = rnd.NextDouble() + rnd.Next(-2, 2);
                points[i].MoveRel(dx, dy);
            }
            Console.WriteLine("Все точки были передвинуты");
            Console.WriteLine("если координаты не изменились - точка была передвинута не по правилам");
            Input(points);
            Console.WriteLine("Все точки были отсиметрирован");
            for (int i = 0; i < points.length; i++)
            {
                points[i].SimO();
            }
            Input(points);
        }
    }
}
