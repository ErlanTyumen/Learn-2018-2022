﻿using System;
using System.Windows.Forms;

namespace Многочлен_Лагранжа_и_Ньютона
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int n;
        double h;
        double[] X;
        double[] Y;
        double Function(double x)
        {
            return Math.Pow(Math.E, x);
            //return Math.Cos(x);
            //return x * x;
        }
        double Fact(int i)
        {
            if (i == 0) return 1;
            return i * Fact(i - 1);
        }
        double C(int k, int j)
        {
            return Fact(k) / (Fact(j) * Fact(k - j));
        }
        double DeltaY(int k, int i)
        {
            double a = 0;
            for (int j = 0; j <= k; j++)
                a += Math.Pow(-1, j) * C(k, j) * Y[k + i - j];
            return a;
        }
        double Rn(double x)
        {
            double p = 1;
            double q = (x - X[0]) / h;
            for (int i = 0; i <= n; i++)
            {
                p *= q - i;
            }
            return Math.Pow(h, n+1) * p * Function(X[n]) / Fact(n+1);
        }
        double Newton(double x)
        {
            double q = (x - X[0]) / h;
            double nx = Y[0];
            for (int i = 1; i <= n; i++)
            {
                double p = 1;
                for (int j = 0; j < i; j++)
                {
                    p *= (q - j);
                }
                p *= DeltaY(i, 0) / Fact(i);
                nx += p;
            }
            return nx;
        }
        double Lagrange(double x)
        {
            double s = 0;
            for (int i = 0; i <= n; i++)
            {
                double p = 1;
                for (int j = 0; j <= n; j++)
                {
                    if (i != j)
                    {
                        p *= (x - X[j]) / (X[i] - X[j]);
                    }
                }
                s += Y[i] * p;
            }
            return s;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            n = 5;
            double a = 1;
            double b = 2;
            X = new double[n + 1];
            Y = new double[n + 1];
            h = (double)(b - a) / n;
            DataG.RowCount = 2 * n + 2;
            DataG.ColumnCount = 2 * n;
            DataG[0, 0].Value = "xᵢ=x₀+ih/2";
            DataG[1, 0].Value = "F(xᵢ)";
            DataG[2, 0].Value = "Ln(xᵢ)";
            DataG[3, 0].Value = "Pn(xᵢ)";
            DataG[4, 0].Value = "Δ";
            DataG[5, 0].Value = "Rn(xᵢ)";
            for (int i = 0; i <= n; i++)
            {
                X[i] = a + i * h;
                Y[i] = Function(X[i]);
            }

            for (int i = 1; i <= 2 * n + 1; i++)
            {
                double x = a + (i - 1) * h / 2;
                DataG[0, i].Value = x;
                DataG[1, i].Value = Math.Round(Function(x), 13);
                DataG[2, i].Value = Math.Round(Lagrange(x), 13);
                DataG[3, i].Value = Math.Round(Newton(x), 13);
                DataG[4, i].Value = Math.Round(Math.Abs((double)DataG[1, i].Value - (double)DataG[2, i].Value), 13);
                DataG[5, i].Value = Math.Round(Rn(x), 13);
            }
        }
    }
}